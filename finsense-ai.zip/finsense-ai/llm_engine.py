"""LLM layer: Gemini explains ML outputs. Falls back to an offline rule-based explainer."""
import json
import os

from dotenv import load_dotenv

load_dotenv()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

SYSTEM = (
    "You are FinSense, a friendly personal-finance copilot for an Indian student. "
    "Use ONLY the JSON facts provided (amounts are in INR). Never invent numbers. "
    "Be concise, specific, and give 2-3 practical, actionable tips. This is not financial advice."
)


def llm_available() -> bool:
    return bool(os.getenv("GEMINI_API_KEY"))


def _fallback(question: str, facts: dict) -> str:
    cats = facts["spend_by_category"]
    top = list(cats.items())[:3]
    q = question.lower()
    lines = []
    if any(w in q for w in ["anomal", "unusual", "suspicious", "odd"]):
        if facts["anomalies"]:
            lines.append("Unusually high transactions detected:")
            lines += [f"- {a['date']}: {a['description']} - Rs {a['amount']:,.0f} ({a['category']})" for a in facts["anomalies"][:5]]
        else:
            lines.append("No unusual spends detected.")
    elif any(w in q for w in ["forecast", "next month", "predict", "budget"]):
        lines.append(f"Predicted spend next month: about Rs {facts['forecast_total']:,.0f}.")
        lines += [f"- {k}: Rs {v:,.0f}" for k, v in list(facts["forecast_next_month"].items())[:5]]
    else:
        lines.append(f"Between {facts['period']} you spent Rs {facts['total_spend']:,.0f} "
                     f"(avg Rs {facts['avg_monthly_spend']:,.0f}/month).")
        lines.append("Top categories: " + ", ".join(f"{k} (Rs {v:,.0f})" for k, v in top) + ".")
        rising = sorted(facts["last_month_change_pct"].items(), key=lambda kv: kv[1], reverse=True)[:1]
        if rising:
            lines.append(f"Biggest month-on-month rise: {rising[0][0]} ({rising[0][1]:+.1f}%).")
        lines.append(f"Tip: set a cap on {top[0][0]} and review it weekly.")
    lines.append("\n(Offline mode - add GEMINI_API_KEY for full AI answers.)")
    return "\n".join(lines)


def ask(question: str, facts: dict) -> str:
    if not llm_available():
        return _fallback(question, facts)
    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
        resp = client.models.generate_content(
            model=MODEL,
            contents=f"FACTS:\n{json.dumps(facts, indent=2)}\n\nQUESTION: {question}",
            config=types.GenerateContentConfig(system_instruction=SYSTEM, temperature=0.3),
        )
        return resp.text
    except Exception as e:  # network/key/model errors -> graceful fallback
        return _fallback(question, facts) + f"\n\n[LLM error: {type(e).__name__}]"
