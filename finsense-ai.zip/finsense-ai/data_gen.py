"""Generate a realistic synthetic UPI/bank transaction dataset (INR, 12 months)."""
import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

CATEGORIES = {
    "Food & Dining": (["Swiggy order", "Zomato order", "Saravana Bhavan", "Murugan Idli Shop", "Starbucks", "Dominos Pizza", "Chai Kingdom"], 120, 450),
    "Groceries": (["Big Basket", "Zepto", "Blinkit", "Reliance Fresh", "Nilgiris supermarket", "Local vegetable vendor"], 150, 1800),
    "Transport": (["Uber ride", "Ola cab", "Rapido bike", "Chennai Metro recharge", "MTC bus pass", "IRCTC ticket", "Petrol bunk"], 40, 600),
    "Shopping": (["Amazon purchase", "Flipkart order", "Myntra", "Decathlon", "Croma electronics", "Ajio fashion"], 300, 3500),
    "Bills & Utilities": (["TNEB electricity bill", "Airtel recharge", "Jio recharge", "Broadband bill", "Metro water tax", "Gas cylinder booking"], 200, 2200),
    "Entertainment": (["Netflix", "Spotify", "BookMyShow movie", "Prime Video", "Hotstar", "Gaming top-up"], 99, 900),
    "Education": (["Udemy course", "Coursera subscription", "College fees", "Stationery shop", "Online exam fee", "GitHub Copilot"], 200, 5000),
    "Health": (["Apollo Pharmacy", "MedPlus", "Clinic consultation", "Lab test", "Gym membership"], 100, 1500),
}
# Typical transactions per month per category
FREQ = {"Food & Dining": 22, "Groceries": 8, "Transport": 18, "Shopping": 4,
        "Bills & Utilities": 5, "Entertainment": 3, "Education": 2, "Health": 2}


def generate(months: int = 12, end: str = "2026-10-31") -> pd.DataFrame:
    end_ts = pd.Timestamp(end)
    start = (end_ts - pd.DateOffset(months=months)).normalize() + pd.Timedelta(days=1)
    rows = []
    for cat, (merchants, lo, hi) in CATEGORIES.items():
        n = FREQ[cat] * months
        dates = start + pd.to_timedelta(RNG.integers(0, (end_ts - start).days + 1, n), unit="D")
        for d in dates:
            amt = float(np.round(RNG.lognormal(np.log((lo + hi) / 3), 0.45), 0))
            amt = float(np.clip(amt, lo, hi))
            m = RNG.choice(merchants)
            suffix = RNG.choice(["", " UPI", " Chennai", f" #{RNG.integers(1000, 9999)}"])
            rows.append((d, f"{m}{suffix}".strip(), amt, cat))
    df = pd.DataFrame(rows, columns=["date", "description", "amount", "category"])
    # inject a few unusual spends
    idx = RNG.choice(len(df), 6, replace=False)
    df.loc[idx, "amount"] = (df.loc[idx, "amount"] * RNG.uniform(6, 12, 6)).round(0)
    return df.sort_values("date").reset_index(drop=True)


if __name__ == "__main__":
    df = generate()
    df.to_csv("data/transactions.csv", index=False)
    print(df.shape)
    print(df.head())
