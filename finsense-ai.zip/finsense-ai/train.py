"""Generate data, train the categoriser, and print evaluation."""
import data_gen
from ml_engine import train_categorizer

df = data_gen.generate()
df.to_csv("data/transactions.csv", index=False)
clf, rep = train_categorizer(df)
print(f"Categoriser accuracy: {rep['accuracy']:.3f}  macro-F1: {rep['macro avg']['f1-score']:.3f}")
