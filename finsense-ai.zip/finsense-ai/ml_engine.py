"""Classical ML components: categoriser, anomaly detector, forecaster."""
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline

MODEL_PATH = "models/categorizer.joblib"


# 1) Text classifier: transaction description -> category
def train_categorizer(df: pd.DataFrame, save: bool = True):
    X_tr, X_te, y_tr, y_te = train_test_split(
        df["description"], df["category"], test_size=0.2, stratify=df["category"], random_state=42)
    clf = make_pipeline(
        TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), lowercase=True),
        LogisticRegression(max_iter=2000, C=5),
    )
    clf.fit(X_tr, y_tr)
    report = classification_report(y_te, clf.predict(X_te), output_dict=True)
    if save:
        joblib.dump(clf, MODEL_PATH)
    return clf, report


def load_categorizer():
    return joblib.load(MODEL_PATH)


def categorize(df: pd.DataFrame, clf) -> pd.DataFrame:
    out = df.copy()
    proba = clf.predict_proba(out["description"])
    out["pred_category"] = clf.classes_[proba.argmax(axis=1)]
    out["confidence"] = proba.max(axis=1).round(3)
    return out


# 2) Unsupervised anomaly detection per category (Isolation Forest)
def detect_anomalies(df: pd.DataFrame, cat_col: str = "pred_category") -> pd.DataFrame:
    flagged = []
    for cat, g in df.groupby(cat_col):
        if len(g) < 15:
            continue
        x = np.log1p(g[["amount"]].values)
        iso = IsolationForest(contamination=0.02, random_state=42).fit(x)
        mask = iso.predict(x) == -1
        # keep only unusually HIGH spends
        high = g["amount"].values > g["amount"].median() * 2.5
        flagged.append(g[mask & high])
    if not flagged:
        return df.iloc[0:0]
    return pd.concat(flagged).sort_values("amount", ascending=False)


# 3) Next-month forecast per category (Ridge on trend + last-3-month mean)
def monthly_table(df: pd.DataFrame, cat_col: str = "pred_category") -> pd.DataFrame:
    d = df.copy()
    d["month"] = pd.to_datetime(d["date"]).dt.to_period("M")
    return d.pivot_table(index="month", columns=cat_col, values="amount", aggfunc="sum", fill_value=0)


def forecast_next_month(monthly: pd.DataFrame) -> pd.Series:
    preds = {}
    t = np.arange(len(monthly)).reshape(-1, 1)
    for cat in monthly.columns:
        y = monthly[cat].values
        if len(y) >= 4:
            model = Ridge(alpha=1.0).fit(t, y)
            trend = model.predict([[len(y)]])[0]
            preds[cat] = max(0.0, 0.5 * trend + 0.5 * y[-3:].mean())
        else:
            preds[cat] = float(y.mean())
    return pd.Series(preds).round(0).sort_values(ascending=False)


def build_facts(df: pd.DataFrame) -> dict:
    """Condense ML outputs into a compact fact sheet for the LLM."""
    monthly = monthly_table(df)
    fc = forecast_next_month(monthly)
    anomalies = detect_anomalies(df)
    last, prev = monthly.iloc[-1], monthly.iloc[-2] if len(monthly) > 1 else monthly.iloc[-1]
    change = ((last - prev) / prev.replace(0, np.nan) * 100).round(1).dropna()
    return {
        "period": f"{monthly.index[0]} to {monthly.index[-1]}",
        "total_spend": float(df["amount"].sum()),
        "avg_monthly_spend": float(monthly.sum(axis=1).mean()),
        "last_month_total": float(last.sum()),
        "spend_by_category": df.groupby("pred_category")["amount"].sum().round(0).sort_values(ascending=False).to_dict(),
        "last_month_change_pct": change.to_dict(),
        "forecast_next_month": fc.to_dict(),
        "forecast_total": float(fc.sum()),
        "anomalies": [
            {"date": str(r.date)[:10], "description": r.description, "amount": float(r.amount), "category": r.pred_category}
            for r in anomalies.head(8).itertuples()
        ],
    }
