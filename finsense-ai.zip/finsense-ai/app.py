"""FinSense AI - Gradio app combining ML models and an LLM."""
import os

import gradio as gr
import matplotlib
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import llm_engine
from ml_engine import build_facts, categorize, load_categorizer, monthly_table

if not os.path.exists("models/categorizer.joblib"):
    import train  # noqa: F401  (trains on first run)

clf = load_categorizer()


def analyze(file):
    path = file.name if file is not None else "data/transactions.csv"
    df = pd.read_csv(path)
    missing = {"date", "description", "amount"} - set(df.columns)
    if missing:
        raise gr.Error(f"CSV is missing columns: {', '.join(sorted(missing))}")
    df = categorize(df, clf)
    facts = build_facts(df)
    monthly = monthly_table(df)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    monthly.index = monthly.index.astype(str)
    monthly.plot(kind="bar", stacked=True, ax=ax, colormap="tab20")
    ax.set_ylabel("Spend (INR)"); ax.set_xlabel("")
    ax.legend(fontsize=7, ncol=2); plt.tight_layout()
    summary = llm_engine.ask("Give a short overview of my spending and 3 tips.", facts)
    anomalies = pd.DataFrame(facts["anomalies"])
    forecast = pd.DataFrame({"category": facts["forecast_next_month"].keys(),
                             "predicted_next_month_INR": facts["forecast_next_month"].values()})
    return summary, fig, anomalies, forecast, df.head(50), facts


def chat(question, history, facts):
    if not facts:
        return history + [{"role": "assistant", "content": "Click 'Analyze' first."}], ""
    answer = llm_engine.ask(question, facts)
    return history + [{"role": "user", "content": question}, {"role": "assistant", "content": answer}], ""


with gr.Blocks(title="FinSense AI") as demo:
    gr.Markdown("# FinSense AI\nML models categorise, flag and forecast your spending; an LLM explains it. "
                "Upload a CSV (`date, description, amount`) or use the demo data.\n"
                f"LLM mode: **{'Gemini' if llm_engine.llm_available() else 'offline fallback'}**")
    facts_state = gr.State({})
    f = gr.File(label="Transactions CSV (optional)", file_types=[".csv"])
    btn = gr.Button("Analyze", variant="primary")
    summary = gr.Markdown()
    plot = gr.Plot()
    with gr.Row():
        an = gr.Dataframe(label="Unusual spends (Isolation Forest)")
        fc = gr.Dataframe(label="Next-month forecast (Ridge)")
    tx = gr.Dataframe(label="Auto-categorised transactions (TF-IDF + Logistic Regression)")
    bot = gr.Chatbot(type="messages", label="Ask FinSense")
    q = gr.Textbox(placeholder="e.g. Why is my food spend high? Any suspicious payments?")
    btn.click(analyze, f, [summary, plot, an, fc, tx, facts_state])
    q.submit(chat, [q, bot, facts_state], [bot, q])

if __name__ == "__main__":
    demo.launch()
